package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.User;

public interface UserRepository extends JpaRepository<UserRepository, Long>{

	static UserRepository saveAll(User user) {
	
		return null;
	}
	

}	
